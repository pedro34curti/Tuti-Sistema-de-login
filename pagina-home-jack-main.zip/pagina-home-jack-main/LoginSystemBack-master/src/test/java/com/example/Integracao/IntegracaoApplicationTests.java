package com.example.Integracao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegracaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
