import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../App.css'

function Home() {
    return(
    <div>
        <h1>Bem vindo a Home</h1>
    </div>
    )
}

export default Home;